﻿
using System;

namespace AppThermostat
{
    /// <summary>
    /// Ce programme instancie un objet de la classe Thermostat, il permet d'augmenter ou de diminuer la température
    /// d'un degrés à la fois. La température autorisée est entre 5 et 35 degrés Celcius.
    /// 
    ///  TODO : Ajoutez une nouvelle classe au projet nommée Thermostat qui correspond au document.
    /// </summary>
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}